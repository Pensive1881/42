#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../../../ex12/ft_print_memory.c"
#include "../../../utils/constants.h"

int test1(void)
{
	printf("    " RED "[1] Sorry. Test not yet implemented\n");
	return (-1);
}

int main(void)
{
	if (test1() != 0)
		return (-1);
	return (0);
}