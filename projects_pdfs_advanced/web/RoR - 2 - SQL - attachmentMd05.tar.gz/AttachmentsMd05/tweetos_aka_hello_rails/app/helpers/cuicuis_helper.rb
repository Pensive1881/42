module CuicuisHelper
end
