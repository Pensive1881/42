# frozen_string_literal: true

module Taillste
  VERSION = "0.1.0"
end
